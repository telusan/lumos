# Деплой Lumos: Netlify + Render + Neon

## 1. База данных Neon.tech

1. Зарегистрируйся на https://neon.tech
2. Create project → скопируй **Connection string**
3. Вид: `postgresql://user:pass@ep-xxx.region.aws.neon.tech/neondb?sslmode=require`

---

## 2. Бэкенд на Render.com

1. https://render.com → New → **Web Service**
2. Подключи GitHub-репозиторий **или** загрузи папку `backend` (Manual Deploy)
3. Настройки:
   - **Root Directory:** `backend` (если репо = весь lumos)
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Environment Variables:
   - `DATABASE_URL` = строка из Neon (как есть)
   - `SECRET_KEY` = любой длинный случайный текст
5. Deploy → получишь URL вида `https://lumos-api.onrender.com`

Проверка: открой `https://твой-url.onrender.com/docs`

---

## 3. Фронтенд на Netlify

1. https://netlify.com → Add new site → Import (GitHub) или drag&drop папки `frontend` после `npm run build`
2. Если через Git:
   - **Base directory:** `frontend`
   - **Build command:** `npm run build`
   - **Publish directory:** `frontend/dist`
3. Environment variables:
   - `VITE_API_URL` = `https://lumos-api.onrender.com`  
     (URL бэкенда **без** `/api/v1` и без слэша в конце)
4. Deploy

Файл `netlify.toml` уже настроен (SPA redirects).

---

## 4. Локально после обновления кода

```cmd
cd backend
pip install -r requirements.txt
python run.py
```

```cmd
cd frontend
npm install
npm run dev
```

Для продакшена локально можно создать `frontend/.env`:
```
VITE_API_URL=https://твой-backend.onrender.com
```

---

## Важно

- Первый запрос к Render может «просыпаться» 30–60 сек (бесплатный план).
- CORS уже разрешён для всех доменов.
- Если Neon URL начинается с `postgres://` — код сам заменит на `postgresql+asyncpg://`.
